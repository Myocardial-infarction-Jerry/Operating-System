#include <stdio.h>
#include "print.h"

void print_something() {
	    printf("SYSU 2023 Spring Operating System Course.\n");
}
